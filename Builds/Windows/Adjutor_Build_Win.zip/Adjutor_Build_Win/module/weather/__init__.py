from .weather import temp_max
from .weather import temp_min
from .weather import humidity
from .weather import status
from .weather import wind_speed
from .weather import display_pic